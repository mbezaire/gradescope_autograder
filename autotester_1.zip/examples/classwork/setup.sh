apt-get -y install openjdk-8-jdk

