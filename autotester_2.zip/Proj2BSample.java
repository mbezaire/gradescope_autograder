public class Proj2BSample
{
  public static void main(String[] args)
  {
    int x = 3;
    int y = 2;
    System.out.println(x);
    System.out.println(y);
    x = y;
    System.out.println(x);
    System.out.println(y);
    y = 5;
    System.out.println(x);
    System.out.println(y);
    y = y + 1;
    System.out.println(y);
  }
}